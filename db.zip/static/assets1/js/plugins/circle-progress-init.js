$('#circle1').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 5,
    fill: {
      gradient: ["red", "orange"]
    }
  });
$('#circle2').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 5,
    fill: {
      gradient: ["red", "orange"]
    }
  });
$('#circle3').circleProgress({
    value: 0.75,
    size: 50,
    thickness: 5,
    fill: {
      gradient: ["red", "orange"]
    }
  });

  
